# On-Page SEO Checklist

- [ ] Unique, compelling title tag (<60 chars)
- [ ] Meta description with value prop (<155 chars)
- [ ] Single H1, descriptive H2/H3
- [ ] Primary keyword in first 100 words
- [ ] Descriptive alt text on images
- [ ] Internal links to relevant pages
- [ ] Schema markup (where applicable)
- [ ] Fast load, mobile-friendly
