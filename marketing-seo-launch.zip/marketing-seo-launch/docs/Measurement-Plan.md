# Measurement Plan

## Event & Conversion Tracking (GA4)
- Outbound link clicks
- CTA button clicks
- Form submit (lead)
- Scroll depth 50%

## Reporting
- Weekly scorecard: traffic, engagement, top pages, top queries
- Channel performance with UTM parameters
- SEO progress: impressions, clicks, average position
