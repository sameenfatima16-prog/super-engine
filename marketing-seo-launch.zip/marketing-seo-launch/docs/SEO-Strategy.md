# SEO Strategy

## 1) Keyword Research
- Seed keywords, competitor terms, SERP features
- Prioritize by intent (informational/transactional), volume, difficulty

## 2) On-Page Optimization
- Title tags, meta descriptions, H1/H2 structure
- Internal linking, image alts, schema markup
- Core Web Vitals hygiene

## 3) Content Plan
- Pillar pages + supporting posts
- Publishing cadence and owners
- Briefs with target keyword, angle, outline, CTAs

## 4) Technical
- robots.txt rules
- XML sitemap and Search Console submission
- 301s for any legacy URLs

## 5) Measurement
- Track impressions, clicks, CTR (GSC)
- Track traffic, engagement, conversions (GA4)
