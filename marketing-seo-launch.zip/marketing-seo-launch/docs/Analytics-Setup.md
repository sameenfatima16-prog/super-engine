# Analytics Setup

## GA4
1. Create a property and Web data stream.
2. Copy your Measurement ID (G-XXXXXXXXXX).
3. Add to the `gtag` snippet in `src/website/index.html`.

## Search Console
1. Verify domain.
2. Submit `seo/technical/sitemap.xml` once live.
