# Digital Launch Plan

## Channels
- **Social:** Teasers, countdowns, launch day announcement, post-launch highlights
- **Email:** Warm-up → launch → follow-up → nurture
- **Paid Ads:** Search + social ads with tight audiences and clear CTAs

## Creative
- Consistent visuals, value props, and landing pages
- UTM tagging for every link

## Cadence (example)
- T-7 days: Teaser
- T-3 days: Feature spotlight
- Launch day: Big announcement
- +3 to +14 days: Proof (testimonials, case studies), retargeting
