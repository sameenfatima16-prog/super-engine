# Contributing

1. Create a feature branch from `main`.
2. Use conventional commits, e.g., `feat: add content calendar`, `fix: correct UTM builder`.
3. For data files, do **not** commit PII or secrets.
4. Open a PR with a concise description and checklist.
