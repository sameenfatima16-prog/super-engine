# Email Sequence

1) **Warm-up:** value-led introduction + teaser (T-5 to T-3 days)
2) **Launch:** announce the new website, key benefits, primary CTA
3) **Follow-up:** social proof, top content picks, secondary CTA
4) **Nurture:** weekly helpful content (3-4 weeks)
