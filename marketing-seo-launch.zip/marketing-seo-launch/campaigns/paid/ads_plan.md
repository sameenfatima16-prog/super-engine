# Paid Ads Plan

## Channels
- Google Search (high-intent keywords)
- Meta/Instagram (awareness + retargeting)
- LinkedIn (B2B, if relevant)

## Structure
- Campaigns by intent/audience
- Ad groups by keyword themes
- Landing pages aligned to ad promise

## Tracking
- Use UTM from `scripts/utm_builder.py`
