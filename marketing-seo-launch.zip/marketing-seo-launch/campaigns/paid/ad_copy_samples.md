# Ad Copy Samples

## Search (RSA)
- Headline ideas: New [Brand] Website, Explore [Benefit], Free [Resource]
- Descriptions: Discover [Value Prop]. Learn more today.

## Social
- Hook → Value → CTA
- Use 1:1 or 4:5 images; short videos for teasers
