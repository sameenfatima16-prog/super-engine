#!/usr/bin/env python3
"""Generate UTM-tagged URLs for campaigns.

Usage:
    python scripts/utm_builder.py --url https://www.example.com/landing         --source instagram --medium paid_social --campaign launch_sep         --content teaser --term keyword
"""
import argparse
from urllib.parse import urlencode, urlparse, urlunparse, parse_qsl

def add_utm(url, source, medium, campaign, content=None, term=None):
    parsed = list(urlparse(url))
    q = dict(parse_qsl(parsed[4]))
    q.update({
        "utm_source": source,
        "utm_medium": medium,
        "utm_campaign": campaign,
    })
    if content:
        q["utm_content"] = content
    if term:
        q["utm_term"] = term
    parsed[4] = urlencode(q)
    return urlunparse(parsed)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", required=True)
    ap.add_argument("--source", required=True)
    ap.add_argument("--medium", required=True)
    ap.add_argument("--campaign", required=True)
    ap.add_argument("--content")
    ap.add_argument("--term")
    args = ap.parse_args()
    print(add_utm(args.url, args.source, args.medium, args.campaign, args.content, args.term))

if __name__ == "__main__":
    print(main() or "")
