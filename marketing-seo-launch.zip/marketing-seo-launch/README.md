# Marketing Website Launch & SEO Optimization

This repository contains the complete plan and assets for launching a new website and optimizing it for search (SEO). It includes the digital launch campaign (social, email, paid), a structured SEO strategy (keyword research, on‑page optimization, content planning), and a measurement framework using Google Analytics 4 (GA4) and Google Search Console.

> **Owner:** Sameen Fatima  
> **Created:** 2025-09-03

## Objectives
- Create awareness for the new website
- Drive qualified traffic from multiple channels
- Establish strong organic visibility via SEO
- Track performance with GA4 and Search Console

## Repo Overview
```
marketing-seo-launch/
├─ docs/                  # Strategy docs & playbooks
├─ seo/                   # Keyword research, content plan, on-page checklist
│  └─ technical/          # robots, sitemap, technical notes
├─ campaigns/             # Social, email, paid assets & calendars
├─ data/                  # Raw exports / processed datasets (keep PII out)
├─ scripts/               # Utilities (UTM builder, helpers)
├─ dashboards/            # Reporting & Looker Studio guidance
├─ src/website/           # Basic site scaffold & tracking snippets
└─ .github/workflows/     # CI/checks
```

## Quick Start
1. **Create the GitHub repo**
   ```bash
   git init
   git add .
   git commit -m "Initial commit: Marketing launch + SEO scaffold"
   gh repo create marketing-seo-launch --public --source=. --remote=origin --push
   # or manually create a repo on GitHub, then:
   git remote add origin <your-repo-url>
   git push -u origin main
   ```

2. **Set up analytics**
   - Create a GA4 property and a Web data stream. Add your Measurement ID to `src/website/index.html` where indicated.
   - Verify site in Google Search Console and submit `seo/technical/sitemap.xml` once live.

3. **Run the plan**
   - Fill `seo/keyword_research.csv` and `seo/content_plan.csv`.
   - Populate `campaigns/social/content_calendar.csv` and `campaigns/email/sequence.md`.
   - Configure tracking parameters with `scripts/utm_builder.py`.

## Measurement Plan (High Level)
- **Traffic & acquisition:** sessions, users, new users by channel/campaign/UTM
- **Engagement:** engaged sessions, engagement rate, average engagement time
- **Content:** pageviews, unique users, top landing pages, search queries
- **Goals/Conversions:** micro (newsletter signup, CTA clicks), macro (lead form)

See `docs/Measurement-Plan.md` for full details.

## License
MIT — see `LICENSE`.
